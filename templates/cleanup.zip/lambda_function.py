import boto3

def lambda_handler(event, context):
    instance_id = 'i-032bb68e1c6ad0671'
    
    ec2_client = boto3.client('ec2')
    response = ec2_client.terminate_instances(InstanceIds=[instance_id])
    
    return {
        'statusCode': 200,
        'body': "Instance {instance_id} terminated successfully."
    }
