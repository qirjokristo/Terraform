import boto3

def lambda_handler(event, context):
    instance_id = 'i-08e8f21ecfb080054'
    
    ec2_client = boto3.client('ec2')
    response = ec2_client.terminate_instances(InstanceIds=[instance_id])
    
    return {
        'statusCode': 200,
        'body': "Instance {instance_id} terminated successfully."
    }
