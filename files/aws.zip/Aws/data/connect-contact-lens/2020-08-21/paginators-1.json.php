<?php
// This file was auto-generated from sdk-root/src/data/connect-contact-lens/2020-08-21/paginators-1.json
return [ 'pagination' => [ 'ListRealtimeContactAnalysisSegments' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', ], ],];
