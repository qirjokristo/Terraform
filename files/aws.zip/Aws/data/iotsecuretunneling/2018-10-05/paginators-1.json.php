<?php
// This file was auto-generated from sdk-root/src/data/iotsecuretunneling/2018-10-05/paginators-1.json
return [ 'pagination' => [ 'ListTunnels' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', ], ],];
