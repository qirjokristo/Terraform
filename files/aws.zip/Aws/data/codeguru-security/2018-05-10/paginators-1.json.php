<?php
// This file was auto-generated from sdk-root/src/data/codeguru-security/2018-05-10/paginators-1.json
return [ 'pagination' => [ 'GetFindings' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', 'result_key' => 'findings', ], 'ListFindingsMetrics' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', 'result_key' => 'findingsMetrics', ], 'ListScans' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', 'result_key' => 'summaries', ], ],];
