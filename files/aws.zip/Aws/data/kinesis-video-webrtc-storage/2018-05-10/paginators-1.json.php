<?php
// This file was auto-generated from sdk-root/src/data/kinesis-video-webrtc-storage/2018-05-10/paginators-1.json
return [ 'pagination' => [],];
