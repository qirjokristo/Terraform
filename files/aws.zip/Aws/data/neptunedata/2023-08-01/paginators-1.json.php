<?php
// This file was auto-generated from sdk-root/src/data/neptunedata/2023-08-01/paginators-1.json
return [ 'pagination' => [],];
