<?php
// This file was auto-generated from sdk-root/src/data/internetmonitor/2021-06-03/waiters-2.json
return [ 'version' => 2, 'waiters' => [],];
