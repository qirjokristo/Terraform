<?php
// This file was auto-generated from sdk-root/src/data/ivschat/2020-07-14/paginators-1.json
return [ 'pagination' => [ 'ListLoggingConfigurations' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', ], 'ListRooms' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', ], ],];
