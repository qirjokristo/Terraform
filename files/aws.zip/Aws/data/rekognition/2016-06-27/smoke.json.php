<?php
// This file was auto-generated from sdk-root/src/data/rekognition/2016-06-27/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [ [ 'operationName' => 'ListCollections', 'input' => [], 'errorExpectedFromService' => false, ], ],];
